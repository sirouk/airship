"use strict";
(() => {
  // extension/src/policy.ts
  var BRIDGE_PROTOCOL_VERSION = 1;
  var BRIDGE_PORT_NAME = "airship-bridge/1";
  var ANTHROPIC_TOKEN_USER_AGENT = "axios/1.7.9";
  var ANTHROPIC_OAUTH_INFERENCE_USER_AGENT = "claude-code/1.0.0";
  var BRIDGE_PROVIDERS = Object.freeze(["xai", "anthropic"]);
  var BRIDGE_METHODS = Object.freeze(["GET", "POST"]);
  var BRIDGE_LIMITS = Object.freeze({
    maxRequestIdLength: 128,
    maxEnvelopeKeys: 16,
    maxUrlLength: 2048,
    maxRequestBodyBytes: 256 * 1024,
    maxHeaderEntries: 16,
    maxHeaderNameLength: 64,
    maxHeaderValueLength: 8192,
    maxResponseBytes: 8 * 1024 * 1024,
    maxStreamResponseBytes: 16 * 1024 * 1024,
    maxChunkBytes: 32 * 1024,
    maxChunks: 8192,
    maxConcurrentRequests: 4,
    bufferedDeadlineMs: 6e4,
    streamDeadlineMs: 3e5,
    streamIdleDeadlineMs: 45e3
  });
  var BRIDGE_DESTINATIONS = Object.freeze([
    Object.freeze({
      provider: "xai",
      prefix: "https://auth.x.ai/oauth2/"
    }),
    Object.freeze({
      provider: "xai",
      prefix: "https://api.x.ai/v1/"
    }),
    // Measured: the Anthropic token host answers 429 to `Mozilla/5.0` and reaches
    // code validation for `axios/1.7.9`.
    Object.freeze({
      provider: "anthropic",
      prefix: "https://claude.ai/oauth/",
      userAgent: ANTHROPIC_TOKEN_USER_AGENT
    }),
    Object.freeze({
      provider: "anthropic",
      prefix: "https://platform.claude.com/v1/oauth/",
      userAgent: ANTHROPIC_TOKEN_USER_AGENT
    }),
    // Anthropic's OAuth inference path is served to the Claude Code fingerprint.
    // An API-key Anthropic call never comes through the bridge, so this value
    // applies only to bridged OAuth inference.
    Object.freeze({
      provider: "anthropic",
      prefix: "https://api.anthropic.com/v1/",
      userAgent: ANTHROPIC_OAUTH_INFERENCE_USER_AGENT
    })
  ]);
  var FORWARDED_REQUEST_HEADERS = Object.freeze([
    "accept",
    "anthropic-beta",
    "anthropic-version",
    "authorization",
    "content-type",
    "user-agent",
    "x-app"
  ]);
  var RETURNED_RESPONSE_HEADERS = Object.freeze([
    "anthropic-request-id",
    "content-type",
    "request-id",
    "retry-after",
    "x-request-id"
  ]);
  var RELEASE_CALLERS = Object.freeze([
    Object.freeze({ origin: "https://sirouk.github.io", pathPrefix: "/airship/" })
  ]);
  function developmentCallers() {
    return Object.freeze([
      ...RELEASE_CALLERS,
      Object.freeze({ origin: "http://localhost:4173", pathPrefix: "/" }),
      Object.freeze({ origin: "http://127.0.0.1:4173", pathPrefix: "/" })
    ]);
  }
  function checkCallerUrl(documentUrl, callers2) {
    if (typeof documentUrl !== "string" || documentUrl.length === 0) {
      return Object.freeze({ ok: false, reason: "The sender reported no frame URL." });
    }
    let url;
    try {
      url = new URL(documentUrl);
    } catch {
      return Object.freeze({ ok: false, reason: "The sender frame URL is unparseable." });
    }
    const caller = callers2.find(
      (candidate) => url.origin === candidate.origin && url.pathname.startsWith(candidate.pathPrefix)
    );
    if (!caller) {
      return Object.freeze({ ok: false, reason: `${url.origin}${url.pathname} is not an Airship page.` });
    }
    return Object.freeze({ ok: true, origin: caller.origin });
  }

  // extension/src/protocol.ts
  var MAX_REASON_LENGTH = 512;
  function isRecord(value) {
    return !!value && typeof value === "object" && !Array.isArray(value);
  }
  function reply(id, fields) {
    return Object.freeze({
      airshipBridge: BRIDGE_PROTOCOL_VERSION,
      from: "extension",
      id,
      ...fields
    });
  }
  function errorReply(id, code, message) {
    const reason = `${code}: ${message}`.replace(/[\u0000-\u001f\u007f]+/gu, " ").slice(0, MAX_REASON_LENGTH);
    return reply(id, { kind: "error", reason });
  }
  function isBridgeReply(value) {
    if (!isRecord(value)) return false;
    if (value.airshipBridge !== BRIDGE_PROTOCOL_VERSION) return false;
    if (value.from !== "extension") return false;
    if (typeof value.id !== "string") return false;
    return value.kind === "hello" || value.kind === "head" || value.kind === "chunk" || value.kind === "end" || value.kind === "error";
  }
  function isTerminalReply(value) {
    return value.kind === "hello" || value.kind === "end" || value.kind === "error";
  }

  // extension/src/content-bridge.ts
  function ignore(reason) {
    return Object.freeze({ action: "ignore", reason });
  }
  function classifyPageMessage(event, context) {
    if (event.source !== context.self) return ignore("The message did not come from this window.");
    const caller = checkCallerUrl(context.url, context.callers);
    if (!caller.ok) return ignore(caller.reason);
    if (event.origin !== caller.origin) return ignore("The message origin is not this page's origin.");
    const data = event.data;
    if (!data || typeof data !== "object" || Array.isArray(data)) {
      return ignore("The message is not an object.");
    }
    const record = data;
    if (record.airshipBridge !== BRIDGE_PROTOCOL_VERSION) return ignore("Not a bridge envelope.");
    if (record.from === "extension") return ignore("A reply is not a request.");
    if (typeof record.kind !== "string") return ignore("The envelope names no request kind.");
    if (typeof record.id !== "string" || record.id.length === 0) {
      return ignore("The envelope carries no request id.");
    }
    return Object.freeze({
      action: "relay",
      message: record,
      id: record.id,
      kind: record.kind,
      origin: caller.origin
    });
  }
  var DEFAULT_MAX_OUTSTANDING = 32;
  function createPageChannel(options) {
    const maxOutstanding = options.maxOutstanding ?? DEFAULT_MAX_OUTSTANDING;
    const outstanding = /* @__PURE__ */ new Map();
    let port;
    function deliver(message, origin) {
      options.postToPage(message, origin);
    }
    function settle(id) {
      outstanding.delete(id);
    }
    function ensurePort(origin) {
      if (port) return port;
      let opened;
      try {
        opened = options.connect();
      } catch {
        return void 0;
      }
      opened.onMessage.addListener((message) => {
        if (!isBridgeReply(message)) return;
        if (isTerminalReply(message)) settle(message.id);
        deliver(message, origin);
      });
      opened.onDisconnect.addListener(() => {
        port = void 0;
        const abandoned = [...outstanding.keys()];
        outstanding.clear();
        for (const id of abandoned) {
          deliver(
            errorReply(id, "bridge-disconnected", "The extension background worker went away."),
            origin
          );
        }
      });
      port = opened;
      return opened;
    }
    return Object.freeze({
      receive(event) {
        const decision = classifyPageMessage(event, options.context);
        if (decision.action !== "relay") return;
        if (outstanding.size >= maxOutstanding) {
          deliver(
            errorReply(decision.id, "too-many-requests", `At most ${maxOutstanding} requests may be outstanding.`),
            decision.origin
          );
          return;
        }
        const active = ensurePort(decision.origin);
        if (!active) {
          deliver(
            errorReply(decision.id, "bridge-disconnected", "The extension background worker is unreachable."),
            decision.origin
          );
          return;
        }
        if (decision.kind !== "cancel") outstanding.set(decision.id, decision.origin);
        try {
          active.postMessage(decision.message);
        } catch {
          settle(decision.id);
          port = void 0;
          deliver(
            errorReply(decision.id, "bridge-disconnected", "The extension background worker is unreachable."),
            decision.origin
          );
        }
      },
      outstanding() {
        return outstanding.size;
      }
    });
  }

  // extension/src/companion.ts
  var COMPANION_PROTOCOL_VERSION = 1;
  var COMPANION_PORT_NAME = "airship-companion/1";
  var MAX_CACHE_RECORD_BYTES = 4 * 1024 * 1024;
  var MAX_CACHE_BYTES = 256 * 1024 * 1024;
  var MAX_VECTOR_BYTES = 4 * 1024 * 1024;
  function isCompanionReply(value) {
    if (!isRecord2(value)) return false;
    return value.airshipCompanion === COMPANION_PROTOCOL_VERSION && value.from === "extension" && typeof value.id === "string" && (value.kind === "hello" || value.kind === "result" || value.kind === "error");
  }
  function isRecord2(value) {
    return !!value && typeof value === "object" && !Array.isArray(value);
  }

  // extension/src/companion-content.ts
  function installCompanionContentBridge(options) {
    const caller = checkCallerUrl(options.documentUrl, options.callers);
    if (!caller.ok || options.self.top !== options.self) return () => void 0;
    let port;
    const outstanding = /* @__PURE__ */ new Set();
    const post = (message) => {
      options.self.postMessage(message, caller.origin);
    };
    const ensurePort = () => {
      if (port) return port;
      try {
        const next = options.runtime.connect({ name: COMPANION_PORT_NAME });
        next.onMessage.addListener((message) => {
          if (!isCompanionReply(message)) return;
          outstanding.delete(message.id);
          post(message);
        });
        next.onDisconnect.addListener(() => {
          port = void 0;
          for (const id of outstanding) {
            post(Object.freeze({
              airshipCompanion: COMPANION_PROTOCOL_VERSION,
              from: "extension",
              id,
              kind: "error",
              code: "companion-disconnected",
              message: "The Airship Companion background context stopped before answering."
            }));
          }
          outstanding.clear();
        });
        port = next;
        return next;
      } catch {
        return void 0;
      }
    };
    const listener = (event) => {
      if (event.source !== options.self || event.origin !== caller.origin) return;
      const value = event.data;
      if (!value || typeof value !== "object" || Array.isArray(value)) return;
      const record = value;
      if (record.airshipCompanion !== COMPANION_PROTOCOL_VERSION || record.from !== "page" || typeof record.id !== "string" || typeof record.kind !== "string") return;
      if (outstanding.size >= 16) {
        post(Object.freeze({
          airshipCompanion: COMPANION_PROTOCOL_VERSION,
          from: "extension",
          id: record.id,
          kind: "error",
          code: "companion-busy",
          message: "The Airship Companion has reached its per-page request limit."
        }));
        return;
      }
      const active = ensurePort();
      if (!active) return;
      outstanding.add(record.id);
      try {
        active.postMessage(record);
      } catch {
        outstanding.delete(record.id);
        port = void 0;
      }
    };
    options.self.addEventListener("message", listener);
    return () => options.self.removeEventListener("message", listener);
  }

  // extension/src/webextension.ts
  function resolveExtensionApi(scope) {
    const candidate = scope.browser ?? scope.chrome;
    return candidate && typeof candidate === "object" && "runtime" in candidate ? candidate : void 0;
  }

  // extension/src/content-script.ts
  var callers = true ? developmentCallers() : RELEASE_CALLERS2;
  var api = resolveExtensionApi(globalThis);
  if (api && window.top === window) {
    const bridge = createPageChannel({
      context: Object.freeze({ self: window, url: location.href, callers }),
      connect: () => api.runtime.connect({ name: BRIDGE_PORT_NAME }),
      postToPage(message, targetOrigin) {
        window.postMessage(message, targetOrigin);
      }
    });
    window.addEventListener("message", (event) => {
      bridge.receive({ data: event.data, origin: event.origin, source: event.source });
    });
    installCompanionContentBridge({
      runtime: api.runtime,
      self: window,
      documentUrl: location.href,
      callers
    });
  }
})();
