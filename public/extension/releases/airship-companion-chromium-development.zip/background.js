"use strict";
(() => {
  // extension/src/policy.ts
  var BRIDGE_PROTOCOL_VERSION = 1;
  var EXTENSION_VERSION = "1.1.0";
  var BRIDGE_PORT_NAME = "airship-bridge/1";
  var ANTHROPIC_TOKEN_USER_AGENT = "axios/1.7.9";
  var ANTHROPIC_OAUTH_INFERENCE_USER_AGENT = "claude-code/1.0.0";
  var BRIDGE_PROVIDERS = Object.freeze(["xai", "anthropic"]);
  var BRIDGE_METHODS = Object.freeze(["GET", "POST"]);
  var BRIDGE_LIMITS = Object.freeze({
    maxRequestIdLength: 128,
    maxEnvelopeKeys: 16,
    maxUrlLength: 2048,
    maxRequestBodyBytes: 256 * 1024,
    maxHeaderEntries: 16,
    maxHeaderNameLength: 64,
    maxHeaderValueLength: 8192,
    maxResponseBytes: 8 * 1024 * 1024,
    maxStreamResponseBytes: 16 * 1024 * 1024,
    maxChunkBytes: 32 * 1024,
    maxChunks: 8192,
    maxConcurrentRequests: 4,
    bufferedDeadlineMs: 6e4,
    streamDeadlineMs: 3e5,
    streamIdleDeadlineMs: 45e3
  });
  var BRIDGE_DESTINATIONS = Object.freeze([
    Object.freeze({
      provider: "xai",
      prefix: "https://auth.x.ai/oauth2/"
    }),
    Object.freeze({
      provider: "xai",
      prefix: "https://api.x.ai/v1/"
    }),
    // Measured: the Anthropic token host answers 429 to `Mozilla/5.0` and reaches
    // code validation for `axios/1.7.9`.
    Object.freeze({
      provider: "anthropic",
      prefix: "https://claude.ai/oauth/",
      userAgent: ANTHROPIC_TOKEN_USER_AGENT
    }),
    Object.freeze({
      provider: "anthropic",
      prefix: "https://platform.claude.com/v1/oauth/",
      userAgent: ANTHROPIC_TOKEN_USER_AGENT
    }),
    // Anthropic's OAuth inference path is served to the Claude Code fingerprint.
    // An API-key Anthropic call never comes through the bridge, so this value
    // applies only to bridged OAuth inference.
    Object.freeze({
      provider: "anthropic",
      prefix: "https://api.anthropic.com/v1/",
      userAgent: ANTHROPIC_OAUTH_INFERENCE_USER_AGENT
    })
  ]);
  function destinationRequiresUserAgentOverride(destination) {
    return typeof destination.userAgent === "string";
  }
  var FORWARDED_REQUEST_HEADERS = Object.freeze([
    "accept",
    "anthropic-beta",
    "anthropic-version",
    "authorization",
    "content-type",
    "user-agent",
    "x-app"
  ]);
  var RETURNED_RESPONSE_HEADERS = Object.freeze([
    "anthropic-request-id",
    "content-type",
    "request-id",
    "retry-after",
    "x-request-id"
  ]);
  var RELEASE_CALLERS = Object.freeze([
    Object.freeze({ origin: "https://sirouk.github.io", pathPrefix: "/airship/" })
  ]);
  function developmentCallers() {
    return Object.freeze([
      ...RELEASE_CALLERS,
      Object.freeze({ origin: "http://localhost:4173", pathPrefix: "/" }),
      Object.freeze({ origin: "http://127.0.0.1:4173", pathPrefix: "/" })
    ]);
  }
  function destinationMatchPatterns(destinations = BRIDGE_DESTINATIONS) {
    return Object.freeze(destinations.map((destination) => `${destination.prefix}*`));
  }
  var DESTINATION_PATH = /^[A-Za-z0-9\-._~/]*$/u;
  function resolveDestination(provider, path, limits = BRIDGE_LIMITS, destinations = BRIDGE_DESTINATIONS) {
    if (typeof path !== "string" || path.length === 0) {
      return Object.freeze({ ok: false, message: "A destination URL is required." });
    }
    if (path.length > limits.maxUrlLength) {
      return Object.freeze({
        ok: false,
        message: `The destination URL exceeds the ${limits.maxUrlLength}-character limit.`
      });
    }
    let url;
    try {
      url = new URL(path);
    } catch {
      return Object.freeze({ ok: false, message: "The destination URL is not absolute." });
    }
    if (url.protocol !== "https:") {
      return Object.freeze({ ok: false, message: "Only https destinations are relayed." });
    }
    if (url.username || url.password) {
      return Object.freeze({ ok: false, message: "The destination URL carries embedded credentials." });
    }
    if (url.hash) {
      return Object.freeze({ ok: false, message: "The destination URL carries a fragment." });
    }
    if (!DESTINATION_PATH.test(url.pathname)) {
      return Object.freeze({
        ok: false,
        message: `The destination URL path may contain only unreserved characters and "/"; percent escapes and path parameters are refused because the origin's router could decode them back off the approved prefix.`
      });
    }
    const destination = destinations.find(
      (candidate) => candidate.provider === provider && url.href.startsWith(candidate.prefix)
    );
    if (!destination) {
      return Object.freeze({
        ok: false,
        message: `${url.origin}${url.pathname} is not an allowlisted ${provider} destination.`
      });
    }
    return Object.freeze({ ok: true, url: url.href, destination });
  }
  var HEADER_NAME = /^[a-z0-9!#$%&'*+.^_`|~-]+$/u;
  var HEADER_VALUE = /^[\x20-\x7e]*$/u;
  function selectRequestHeaders(headers, limits = BRIDGE_LIMITS, allowlist = FORWARDED_REQUEST_HEADERS) {
    const entries = Object.entries(headers);
    if (entries.length > limits.maxHeaderEntries) {
      return Object.freeze({
        ok: false,
        message: `A request may carry at most ${limits.maxHeaderEntries} headers.`
      });
    }
    const forwarded = {};
    const dropped = [];
    const seen = /* @__PURE__ */ new Set();
    let userAgent;
    for (const [rawName, value] of entries) {
      const name = rawName.toLowerCase();
      if (rawName.length > limits.maxHeaderNameLength || !HEADER_NAME.test(name)) {
        return Object.freeze({ ok: false, message: `Header name ${JSON.stringify(rawName)} is invalid.` });
      }
      if (typeof value !== "string" || value.length > limits.maxHeaderValueLength || !HEADER_VALUE.test(value)) {
        return Object.freeze({ ok: false, message: `Header ${name} has an invalid value.` });
      }
      if (seen.has(name)) {
        return Object.freeze({ ok: false, message: `Header ${name} is repeated.` });
      }
      seen.add(name);
      if (!allowlist.includes(name)) {
        dropped.push(name);
        continue;
      }
      if (name === "user-agent") {
        userAgent = value;
        continue;
      }
      forwarded[name] = value;
    }
    return Object.freeze({
      ok: true,
      forwarded: Object.freeze(forwarded),
      dropped: Object.freeze(dropped),
      ...userAgent === void 0 ? {} : { userAgent }
    });
  }
  function selectResponseHeaders(headers, limits = BRIDGE_LIMITS, allowlist = RETURNED_RESPONSE_HEADERS) {
    const selected = {};
    for (const name of allowlist) {
      const value = headers.get(name);
      if (typeof value !== "string") continue;
      if (value.length > limits.maxHeaderValueLength) continue;
      selected[name] = value;
    }
    return Object.freeze(selected);
  }
  function checkCallerUrl(documentUrl, callers2) {
    if (typeof documentUrl !== "string" || documentUrl.length === 0) {
      return Object.freeze({ ok: false, reason: "The sender reported no frame URL." });
    }
    let url;
    try {
      url = new URL(documentUrl);
    } catch {
      return Object.freeze({ ok: false, reason: "The sender frame URL is unparseable." });
    }
    const caller = callers2.find(
      (candidate) => url.origin === candidate.origin && url.pathname.startsWith(candidate.pathPrefix)
    );
    if (!caller) {
      return Object.freeze({ ok: false, reason: `${url.origin}${url.pathname} is not an Airship page.` });
    }
    return Object.freeze({ ok: true, origin: caller.origin });
  }
  function checkSender(sender, callers2) {
    if (!sender) {
      return Object.freeze({ ok: false, reason: "The sender reported no frame URL." });
    }
    if (sender.frameId !== 0) {
      return Object.freeze({
        ok: false,
        reason: typeof sender.frameId === "number" ? "Only the top frame may use the bridge." : "The browser did not identify the sender's frame, so it cannot be shown to be the top frame."
      });
    }
    const caller = checkCallerUrl(sender.url, callers2);
    if (!caller.ok) return caller;
    if (typeof sender.origin === "string" && sender.origin !== caller.origin) {
      return Object.freeze({ ok: false, reason: "The sender origin and frame URL disagree." });
    }
    return caller;
  }
  function describeProviderAvailability(capabilities, destinations = BRIDGE_DESTINATIONS) {
    const providers = [];
    const unavailable = [];
    for (const provider of BRIDGE_PROVIDERS) {
      const owned = destinations.filter((destination) => destination.provider === provider);
      if (owned.length === 0) continue;
      if (capabilities.hostAccess === "missing") {
        unavailable.push(Object.freeze({
          provider,
          reason: "The extension is installed but has not been granted access to the provider hosts."
        }));
        continue;
      }
      const blocked = owned.some(destinationRequiresUserAgentOverride) && capabilities.userAgentOverride !== "live";
      if (blocked) {
        unavailable.push(Object.freeze({
          provider,
          reason: "This browser gives the extension no way to set User-Agent, and the provider's OAuth host rejects browser user agents."
        }));
        continue;
      }
      providers.push(provider);
    }
    return Object.freeze({
      providers: Object.freeze(providers),
      unavailable: Object.freeze(unavailable)
    });
  }

  // extension/src/protocol.ts
  var REQUEST_ID = /^[A-Za-z0-9._:-]+$/u;
  var MAX_REASON_LENGTH = 512;
  function isRecord(value) {
    return !!value && typeof value === "object" && !Array.isArray(value);
  }
  function refuse(id, code, message) {
    return Object.freeze({ ok: false, id, code, message });
  }
  function parseBridgeRequest(raw, limits = BRIDGE_LIMITS) {
    if (!isRecord(raw)) return refuse("", "malformed-request", "The bridge message is not an object.");
    const id = typeof raw.id === "string" ? raw.id : "";
    if (raw.airshipBridge !== BRIDGE_PROTOCOL_VERSION) {
      return refuse(id, "malformed-request", "Unsupported bridge protocol version.");
    }
    if (Object.keys(raw).length > limits.maxEnvelopeKeys) {
      return refuse(id, "malformed-request", "The bridge message carries too many fields.");
    }
    if (raw.from !== void 0 && raw.from !== "page") {
      return refuse(id, "malformed-request", "Only a page may send a bridge request.");
    }
    if (!id || id.length > limits.maxRequestIdLength || !REQUEST_ID.test(id)) {
      return refuse("", "malformed-request", "The bridge message has no usable request id.");
    }
    if (raw.kind === "hello") return Object.freeze({ ok: true, request: Object.freeze({ kind: "hello", id }) });
    if (raw.kind === "cancel") return Object.freeze({ ok: true, request: Object.freeze({ kind: "cancel", id }) });
    if (raw.kind !== "fetch") return refuse(id, "malformed-request", "Unsupported bridge request kind.");
    const provider = raw.provider;
    if (typeof provider !== "string" || !BRIDGE_PROVIDERS.includes(provider)) {
      return refuse(id, "malformed-request", "A fetch request must name a supported provider.");
    }
    if (typeof raw.path !== "string") {
      return refuse(id, "malformed-request", "A fetch request must carry a destination URL.");
    }
    const method = raw.method === void 0 ? "GET" : raw.method;
    if (typeof method !== "string" || !BRIDGE_METHODS.includes(method)) {
      return refuse(id, "malformed-request", "Only GET and POST are relayed.");
    }
    if (raw.headers !== void 0 && !isRecord(raw.headers)) {
      return refuse(id, "malformed-request", "Request headers must be an object.");
    }
    if (raw.stream !== void 0 && typeof raw.stream !== "boolean") {
      return refuse(id, "malformed-request", "The stream flag must be a boolean.");
    }
    let body;
    if (raw.body !== void 0) {
      if (typeof raw.body !== "string") {
        return refuse(id, "malformed-request", "A request body must be a string.");
      }
      if (method !== "POST") {
        return refuse(id, "malformed-request", "Only POST requests may carry a body.");
      }
      if (raw.body.length > limits.maxRequestBodyBytes || new TextEncoder().encode(raw.body).byteLength > limits.maxRequestBodyBytes) {
        return refuse(
          id,
          "request-too-large",
          `A request body may not exceed ${limits.maxRequestBodyBytes} bytes.`
        );
      }
      body = raw.body;
    }
    const rawHeaders = raw.headers ?? {};
    const headers = {};
    let count = 0;
    for (const name in rawHeaders) {
      if (!Object.prototype.hasOwnProperty.call(rawHeaders, name)) continue;
      count += 1;
      if (count > limits.maxHeaderEntries) {
        return refuse(
          id,
          "malformed-request",
          `A request may carry at most ${limits.maxHeaderEntries} headers.`
        );
      }
      const value = rawHeaders[name];
      if (typeof value !== "string") {
        return refuse(id, "malformed-request", `Header ${name} must be a string.`);
      }
      headers[name] = value;
    }
    const request = Object.freeze({
      kind: "fetch",
      id,
      provider,
      path: raw.path,
      method,
      headers: Object.freeze(headers),
      ...body === void 0 ? {} : { body },
      stream: raw.stream === true
    });
    return Object.freeze({ ok: true, request });
  }
  function reply(id, fields) {
    return Object.freeze({
      airshipBridge: BRIDGE_PROTOCOL_VERSION,
      from: "extension",
      id,
      ...fields
    });
  }
  function helloReply(id, availability, version) {
    return reply(id, {
      kind: "hello",
      version,
      providers: availability.providers,
      unavailable: availability.unavailable
    });
  }
  function headReply(id, status, headers) {
    return reply(id, { kind: "head", status, headers });
  }
  function chunkReply(id, seq, data) {
    return reply(id, { kind: "chunk", seq, data });
  }
  function endReply(id, seq) {
    return reply(id, { kind: "end", seq });
  }
  function errorReply(id, code, message) {
    const reason = `${code}: ${message}`.replace(/[\u0000-\u001f\u007f]+/gu, " ").slice(0, MAX_REASON_LENGTH);
    return reply(id, { kind: "error", reason });
  }

  // extension/src/relay.ts
  var DROPPED_HEADER_NOTICE = "x-airship-bridge-dropped";
  var USER_AGENT_NOTICE = "x-airship-bridge-user-agent";
  function createBridgeRelay(options) {
    const limits = options.limits ?? BRIDGE_LIMITS;
    const destinations = options.destinations ?? BRIDGE_DESTINATIONS;
    const version = options.version ?? EXTENSION_VERSION;
    const inflight = /* @__PURE__ */ new Map();
    let disposed = false;
    function emit(message) {
      if (disposed) return;
      options.send(message);
    }
    function terminate(id, entry, message) {
      if (entry.terminated) return;
      entry.terminated = true;
      entry.cancelDeadline();
      entry.cancelIdle();
      inflight.delete(id);
      if (message) emit(message);
    }
    function fail(id, entry, code, message) {
      terminate(id, entry, errorReply(id, code, message));
      entry.controller.abort();
    }
    function reserved(kind) {
      let count = 0;
      for (const entry of inflight.values()) {
        if (entry.kind === kind) count += 1;
      }
      return count;
    }
    async function runHello(request, entry) {
      const availability = describeProviderAvailability(await options.resolveCapabilities(), destinations);
      if (entry.terminated) return;
      terminate(request.id, entry, helloReply(request.id, availability, version));
    }
    async function runFetch(request, entry) {
      const destination = resolveDestination(request.provider, request.path, limits, destinations);
      if (!destination.ok) {
        fail(request.id, entry, "destination-refused", destination.message);
        return;
      }
      const capabilities = await options.resolveCapabilities();
      if (entry.terminated) return;
      if (capabilities.hostAccess === "missing") {
        fail(
          request.id,
          entry,
          "host-access-missing",
          "The extension has not been granted access to the provider hosts."
        );
        return;
      }
      const overrideNeeded = destinationRequiresUserAgentOverride(destination.destination);
      if (overrideNeeded && capabilities.userAgentOverride !== "live") {
        fail(
          request.id,
          entry,
          "user-agent-override-unavailable",
          `${destination.destination.prefix} requires a User-Agent this browser gives the extension no way to set.`
        );
        return;
      }
      const headers = selectRequestHeaders(request.headers, limits);
      if (!headers.ok) {
        fail(request.id, entry, "header-refused", headers.message);
        return;
      }
      if (headers.userAgent !== void 0 && headers.userAgent !== destination.destination.userAgent) {
        fail(
          request.id,
          entry,
          "user-agent-refused",
          `This build sends ${destination.destination.userAgent ?? "the browser's own agent"} to ${destination.destination.prefix} and will not substitute ${headers.userAgent}.`
        );
        return;
      }
      const init = Object.freeze({
        method: request.method,
        headers: headers.forwarded,
        ...request.body === void 0 ? {} : { body: request.body },
        credentials: "omit",
        cache: "no-store",
        mode: "cors",
        redirect: "manual",
        referrerPolicy: "no-referrer",
        keepalive: false,
        signal: entry.controller.signal
      });
      try {
        const response = await options.fetchImpl(destination.url, init);
        if (entry.terminated) return;
        if (isRedirect(response)) {
          fail(
            request.id,
            entry,
            "redirect-refused",
            `The destination answered with redirect status ${response.status}; the bridge never follows redirects, because a redirect target is a destination the allowlist never approved.`
          );
          return;
        }
        if (!Number.isSafeInteger(response.status) || response.status < 200 || response.status > 599) {
          fail(request.id, entry, "status-refused", `The destination answered with status ${response.status}.`);
          return;
        }
        const notices = {};
        if (headers.dropped.length > 0) notices[DROPPED_HEADER_NOTICE] = headers.dropped.join(", ");
        if (destination.destination.userAgent) {
          notices[USER_AGENT_NOTICE] = destination.destination.userAgent;
        }
        emit(headReply(request.id, response.status, Object.freeze({
          ...selectResponseHeaders(response.headers, limits),
          ...notices
        })));
        const chunks = await streamBody(request, response, entry);
        if (entry.terminated) return;
        terminate(request.id, entry, endReply(request.id, chunks));
      } catch (error) {
        if (entry.terminated) return;
        if (error instanceof RelayBoundError) {
          fail(request.id, entry, error.code, error.message);
          return;
        }
        fail(request.id, entry, "network-error", describeError(error));
      }
    }
    async function streamBody(request, response, entry) {
      if (!response.body || BODY_LESS_STATUSES.has(response.status)) return 0;
      const ceiling = request.stream ? limits.maxStreamResponseBytes : limits.maxResponseBytes;
      const reader = response.body.getReader();
      let bytes = 0;
      let seq = 0;
      try {
        for (; ; ) {
          entry.cancelIdle();
          entry.cancelIdle = options.clock.setTimer(limits.streamIdleDeadlineMs, () => {
            fail(request.id, entry, "deadline-exceeded", `The response was idle for ${limits.streamIdleDeadlineMs}ms.`);
          });
          const { value, done } = await reader.read();
          if (entry.terminated) return seq;
          if (done) break;
          bytes += value.byteLength;
          if (bytes > ceiling) {
            throw new RelayBoundError(
              "response-too-large",
              `The response exceeded the ${ceiling}-byte ceiling.`
            );
          }
          seq = emitChunks(request.id, value, seq, entry);
        }
        return seq;
      } finally {
        entry.cancelIdle();
        entry.cancelIdle = () => void 0;
        await reader.cancel().catch(() => void 0);
      }
    }
    function emitChunks(id, value, seq, entry) {
      let next = seq;
      for (let offset = 0; offset < value.byteLength; offset += limits.maxChunkBytes) {
        if (next >= limits.maxChunks) {
          throw new RelayBoundError(
            "too-many-chunks",
            `A response may not exceed ${limits.maxChunks} chunks.`
          );
        }
        if (entry.terminated) return next;
        next += 1;
        emit(chunkReply(id, next, base64(value.subarray(offset, offset + limits.maxChunkBytes))));
      }
      return next;
    }
    return Object.freeze({
      async handle(raw) {
        if (disposed) return;
        const parsed = parseBridgeRequest(raw, limits);
        if (!parsed.ok) {
          emit(errorReply(parsed.id, parsed.code, parsed.message));
          return;
        }
        const request = parsed.request;
        if (request.kind === "cancel") {
          const entry2 = inflight.get(request.id);
          if (entry2) {
            terminate(request.id, entry2, void 0);
            entry2.controller.abort();
          }
          return;
        }
        if (inflight.has(request.id)) {
          emit(errorReply(request.id, "duplicate-request-id", "That request id is already in flight."));
          return;
        }
        const cap = limits.maxConcurrentRequests;
        if (reserved(request.kind) >= cap) {
          emit(errorReply(
            request.id,
            "too-many-requests",
            request.kind === "hello" ? `At most ${cap} bridge handshakes may be in flight.` : `At most ${cap} bridge requests may be in flight.`
          ));
          return;
        }
        const entry = {
          kind: request.kind,
          controller: new AbortController(),
          terminated: false,
          cancelDeadline: () => void 0,
          cancelIdle: () => void 0
        };
        inflight.set(request.id, entry);
        const deadlineMs = request.kind === "fetch" && request.stream ? limits.streamDeadlineMs : limits.bufferedDeadlineMs;
        entry.cancelDeadline = options.clock.setTimer(deadlineMs, () => {
          fail(request.id, entry, "deadline-exceeded", `The request exceeded its ${deadlineMs}ms deadline.`);
        });
        try {
          if (request.kind === "hello") await runHello(request, entry);
          else await runFetch(request, entry);
        } catch (error) {
          fail(request.id, entry, "internal-error", describeError(error));
        } finally {
          if (!entry.terminated) {
            fail(request.id, entry, "internal-error", "The bridge released the request without answering it.");
          }
        }
      },
      inflight() {
        return reserved("fetch");
      },
      dispose() {
        if (disposed) return;
        disposed = true;
        for (const [, entry] of inflight) {
          entry.terminated = true;
          entry.cancelDeadline();
          entry.cancelIdle();
          entry.controller.abort();
        }
        inflight.clear();
      }
    });
  }
  var BODY_LESS_STATUSES = /* @__PURE__ */ new Set([204, 205, 304]);
  function isRedirect(response) {
    if (response.type === "opaqueredirect") return true;
    if (response.redirected === true) return true;
    return response.status >= 300 && response.status < 400 && response.status !== 304;
  }
  function base64(bytes) {
    let binary = "";
    const window = 32768;
    for (let offset = 0; offset < bytes.byteLength; offset += window) {
      binary += String.fromCharCode(...bytes.subarray(offset, offset + window));
    }
    return btoa(binary);
  }
  function describeError(error) {
    const message = error instanceof Error ? error.message : String(error);
    return message.slice(0, 200) || "The relayed request failed.";
  }
  var RelayBoundError = class extends Error {
    code;
    constructor(code, message) {
      super(message);
      this.name = "RelayBoundError";
      this.code = code;
    }
  };

  // extension/src/user-agent.ts
  var USER_AGENT_RULE_ID_BASE = 8100;
  function overrideDestinations(destinations = BRIDGE_DESTINATIONS) {
    return Object.freeze(destinations.filter(destinationRequiresUserAgentOverride));
  }
  function userAgentRules(destinations = BRIDGE_DESTINATIONS) {
    return Object.freeze(overrideDestinations(destinations).map(
      (destination, index) => Object.freeze({
        id: USER_AGENT_RULE_ID_BASE + index,
        priority: 1,
        action: Object.freeze({
          type: "modifyHeaders",
          requestHeaders: Object.freeze([
            Object.freeze({
              header: "user-agent",
              operation: "set",
              value: destination.userAgent ?? ""
            })
          ])
        }),
        // `|` anchors the filter at the start of the URL, so the rule cannot
        // match a destination that merely contains the prefix.
        condition: Object.freeze({
          urlFilter: `|${destination.prefix}`,
          resourceTypes: Object.freeze(["xmlhttprequest"]),
          tabIds: Object.freeze([-1])
        })
      })
    ));
  }
  function applyUserAgentHeader(details, destinations = BRIDGE_DESTINATIONS) {
    if (details.tabId !== -1) return void 0;
    const matched = overrideDestinations(destinations).find((destination) => details.url.startsWith(destination.prefix));
    if (!matched?.userAgent) return void 0;
    const headers = (details.requestHeaders ?? []).filter((header) => header.name.toLowerCase() !== "user-agent").map((header) => ({ name: header.name, value: header.value }));
    headers.push({ name: "User-Agent", value: matched.userAgent });
    return { requestHeaders: headers };
  }
  function ruleReadsBack(rule, installed) {
    const wanted = rule.action.requestHeaders[0];
    if (!wanted) return false;
    return installed.some((candidate) => candidate.id === rule.id && candidate.action?.type === "modifyHeaders" && (candidate.action.requestHeaders ?? []).some((header) => header.header?.toLowerCase() === wanted.header && header.operation === wanted.operation && header.value === wanted.value));
  }
  async function installUserAgentOverride(host, destinations = BRIDGE_DESTINATIONS) {
    const rules = userAgentRules(destinations);
    if (rules.length === 0) return "live";
    const dnr = host?.declarativeNetRequest;
    if (dnr) {
      try {
        await dnr.updateSessionRules({
          addRules: rules,
          removeRuleIds: rules.map((rule) => rule.id)
        });
        const installed = await dnr.getSessionRules();
        if (rules.every((rule) => ruleReadsBack(rule, installed))) return "live";
      } catch {
      }
    }
    const webRequest = host?.webRequest;
    if (webRequest) {
      try {
        const listener = (details) => applyUserAgentHeader(details, destinations);
        webRequest.onBeforeSendHeaders.addListener(
          listener,
          {
            urls: overrideDestinations(destinations).map((destination) => `${destination.prefix}*`),
            types: ["xmlhttprequest"]
          },
          ["blocking", "requestHeaders"]
        );
        const attached = webRequest.onBeforeSendHeaders.hasListener;
        if (typeof attached !== "function" || attached.call(webRequest.onBeforeSendHeaders, listener)) {
          return "live";
        }
      } catch {
      }
    }
    return "unavailable";
  }

  // extension/src/webextension.ts
  function resolveExtensionApi(scope) {
    const candidate = scope.browser ?? scope.chrome;
    return candidate && typeof candidate === "object" && "runtime" in candidate ? candidate : void 0;
  }

  // extension/src/companion.ts
  var COMPANION_PROTOCOL_VERSION = 1;
  var COMPANION_PORT_NAME = "airship-companion/1";
  var DATABASE_NAME = "airship-companion-v1";
  var DATABASE_VERSION = 1;
  var RECORD_STORE = "ciphertext-pages";
  var SETTINGS_STORE = "settings";
  var ENABLED_SETTING = "ciphertext-cache-enabled";
  var MAX_REQUEST_ID_LENGTH = 128;
  var MAX_ENVELOPE_KEYS = 18;
  var MAX_CACHE_RECORD_BYTES = 4 * 1024 * 1024;
  var MAX_CACHE_BYTES = 256 * 1024 * 1024;
  var MAX_CACHE_RECORDS = 4096;
  var MAX_VECTOR_BYTES = 4 * 1024 * 1024;
  var MAX_VECTOR_CANDIDATES = 512;
  var MAX_VECTOR_DIMENSIONS = 2048;
  var MAX_TOP_K = 50;
  var OPAQUE_ID = /^[A-Za-z0-9_-]{16,64}$/u;
  var REQUEST_ID2 = /^[A-Za-z0-9._:-]+$/u;
  var SHA256_DIGEST = /^sha256:[A-Za-z0-9_-]{43}$/u;
  function installCompanionPort(port) {
    let tail = Promise.resolve();
    let disconnected = false;
    port.onDisconnect.addListener(() => {
      disconnected = true;
    });
    port.onMessage.addListener((message) => {
      tail = tail.then(async () => {
        const parsed = parseCompanionRequest(message);
        const response = parsed.ok ? await handleCompanionRequest(parsed.request) : companionError(parsed.id, parsed.code, parsed.message);
        if (!disconnected) port.postMessage(response);
      }).catch(() => {
        if (!disconnected) {
          port.postMessage(companionError("", "internal-error", "The companion request failed closed."));
        }
      });
    });
  }
  async function inspectCompanionCapabilities() {
    const computeAvailable = typeof crypto?.subtle?.digest === "function";
    let storage;
    if (typeof indexedDB === "undefined") {
      storage = Object.freeze({
        state: "unavailable",
        enabled: false,
        backend: "none",
        durability: "none",
        boundary: "ciphertext-cache-only",
        maxRecordBytes: MAX_CACHE_RECORD_BYTES,
        maxCacheBytes: MAX_CACHE_BYTES,
        maxRecords: MAX_CACHE_RECORDS,
        reason: "This extension runtime exposes no IndexedDB database."
      });
    } else {
      try {
        const [enabled, stats, estimate] = await Promise.all([
          companionCacheEnabled(),
          companionCacheStats(),
          storageEstimate()
        ]);
        storage = Object.freeze({
          state: "available",
          enabled,
          backend: "extension-indexeddb",
          durability: "extension-origin-persistent",
          boundary: "ciphertext-cache-only",
          maxRecordBytes: MAX_CACHE_RECORD_BYTES,
          maxCacheBytes: MAX_CACHE_BYTES,
          maxRecords: MAX_CACHE_RECORDS,
          usageBytes: stats.bytes,
          records: stats.records,
          ...estimate.quota !== void 0 ? { quotaBytes: estimate.quota } : {}
        });
      } catch {
        storage = Object.freeze({
          state: "unavailable",
          enabled: false,
          backend: "none",
          durability: "none",
          boundary: "ciphertext-cache-only",
          maxRecordBytes: MAX_CACHE_RECORD_BYTES,
          maxCacheBytes: MAX_CACHE_BYTES,
          maxRecords: MAX_CACHE_RECORDS,
          reason: "The extension-owned cache database could not be opened."
        });
      }
    }
    const compute = Object.freeze({
      state: computeAvailable ? "available" : "unavailable",
      execution: "extension-background",
      operations: computeAvailable ? Object.freeze(["sha256", "cosine-top-k"]) : Object.freeze([]),
      maxVectorBytes: MAX_VECTOR_BYTES,
      maxCandidates: MAX_VECTOR_CANDIDATES,
      maxDimensions: MAX_VECTOR_DIMENSIONS,
      ...computeAvailable ? {} : { reason: "This extension runtime exposes no WebCrypto digest implementation." }
    });
    return Object.freeze({ storage, compute });
  }
  async function companionCacheStats(namespace) {
    const database = await openDatabase();
    try {
      const records = (await allRecords(database)).filter((record) => namespace === void 0 || record.namespace === namespace);
      return Object.freeze({
        records: records.length,
        bytes: records.reduce((total, record) => total + record.size, 0)
      });
    } finally {
      database.close();
    }
  }
  async function handleCompanionRequest(request) {
    if (request.kind === "hello") {
      return companionReply(request.id, {
        kind: "hello",
        version: EXTENSION_VERSION,
        capabilities: await inspectCompanionCapabilities()
      });
    }
    if (request.kind === "compute") return handleCompute(request);
    if (!await companionCacheEnabled()) {
      return companionError(
        request.id,
        "cache-disabled",
        "The extension-owned ciphertext cache is disabled. Enable it from the Airship Companion popup."
      );
    }
    if (request.operation === "stats") {
      return companionReply(request.id, { kind: "result", result: await companionCacheStats(request.namespace) });
    }
    if (request.operation === "list") {
      const database = await openDatabase();
      try {
        const records = (await allRecords(database)).filter((record2) => record2.namespace === request.namespace).map((record2) => Object.freeze({ key: record2.key, bytes: record2.size }));
        return companionReply(request.id, {
          kind: "result",
          result: Object.freeze({ pages: Object.freeze(records) })
        });
      } finally {
        database.close();
      }
    }
    const key = request.key;
    if (!key) return companionError(request.id, "invalid-request", "A cache page key is required.");
    if (request.operation === "put") {
      if (request.ciphertext !== true) {
        return companionError(request.id, "plaintext-refused", "Only caller-declared ciphertext cache pages are accepted.");
      }
      const bytes2 = decodeBase64(request.data ?? "", MAX_CACHE_RECORD_BYTES);
      if (!bytes2 || bytes2.byteLength === 0) {
        return companionError(request.id, "invalid-request", "The ciphertext cache page is empty or invalid.");
      }
      const digest = await sha256(bytes2);
      if (request.digest && request.digest !== digest) {
        return companionError(request.id, "digest-mismatch", "The ciphertext page digest did not match its bytes.");
      }
      await putRecord(Object.freeze({
        id: recordId(request.namespace, key),
        namespace: request.namespace,
        key,
        data: request.data,
        digest,
        size: bytes2.byteLength,
        touchedAt: Date.now()
      }));
      return companionReply(request.id, { kind: "result", result: Object.freeze({ stored: true, digest }) });
    }
    if (request.operation === "remove") {
      await removeRecord(recordId(request.namespace, key));
      return companionReply(request.id, { kind: "result", result: Object.freeze({ removed: true }) });
    }
    const record = await getRecord(recordId(request.namespace, key));
    if (!record) {
      return companionReply(request.id, { kind: "result", result: Object.freeze({ found: false }) });
    }
    const bytes = decodeBase64(record.data, MAX_CACHE_RECORD_BYTES);
    if (!bytes || await sha256(bytes) !== record.digest) {
      await removeRecord(record.id);
      return companionError(request.id, "cache-corrupt", "The cached ciphertext page failed its digest check and was removed.");
    }
    void touchRecord(record).catch(() => void 0);
    return companionReply(request.id, {
      kind: "result",
      result: Object.freeze({ found: true, data: record.data, digest: record.digest, bytes: record.size })
    });
  }
  async function handleCompute(request) {
    if (typeof crypto?.subtle?.digest !== "function") {
      return companionError(request.id, "compute-unavailable", "WebCrypto is unavailable in this extension runtime.");
    }
    if (request.operation === "sha256") {
      const bytes = decodeBase64(request.data, MAX_VECTOR_BYTES);
      if (!bytes) return companionError(request.id, "invalid-request", "The digest input is invalid or too large.");
      return companionReply(request.id, {
        kind: "result",
        result: Object.freeze({ digest: await sha256(bytes), bytes: bytes.byteLength })
      });
    }
    const query = decodeVector(request.query, request.dimensions);
    if (!query) return companionError(request.id, "invalid-request", "The query vector is invalid.");
    const queryNorm = vectorNorm(query);
    if (queryNorm === 0) return companionError(request.id, "invalid-request", "The query vector has zero magnitude.");
    const ranked = [];
    for (const candidate of request.candidates) {
      const vector = decodeVector(candidate.vector, request.dimensions);
      if (!vector) return companionError(request.id, "invalid-request", "A candidate vector is invalid.");
      const norm = vectorNorm(vector);
      let dot = 0;
      for (let index = 0; index < vector.length; index += 1) dot += query[index] * vector[index];
      ranked.push(Object.freeze({ id: candidate.id, score: norm === 0 ? 0 : dot / (queryNorm * norm) }));
    }
    ranked.sort((left, right) => right.score - left.score || left.id.localeCompare(right.id));
    return companionReply(request.id, {
      kind: "result",
      result: Object.freeze({ matches: Object.freeze(ranked.slice(0, request.topK)) })
    });
  }
  function parseCompanionRequest(raw) {
    if (!isRecord2(raw)) return invalid("", "The companion message is not an object.");
    const id = typeof raw.id === "string" ? raw.id : "";
    if (raw.airshipCompanion !== COMPANION_PROTOCOL_VERSION || raw.from !== "page" || !id || id.length > MAX_REQUEST_ID_LENGTH || !REQUEST_ID2.test(id) || Object.keys(raw).length > MAX_ENVELOPE_KEYS) {
      return invalid(id, "The companion envelope is invalid.");
    }
    if (raw.kind === "hello") {
      return Object.freeze({ ok: true, request: Object.freeze({ kind: "hello", id }) });
    }
    if (raw.kind === "cache") {
      const operation = raw.operation;
      const namespace = raw.namespace;
      if (operation !== "get" && operation !== "put" && operation !== "remove" && operation !== "stats" && operation !== "list" || typeof namespace !== "string" || !OPAQUE_ID.test(namespace)) {
        return invalid(id, "The cache operation or namespace is invalid.");
      }
      if (operation !== "stats" && operation !== "list" && (typeof raw.key !== "string" || !OPAQUE_ID.test(raw.key))) {
        return invalid(id, "The cache page key is invalid.");
      }
      if (operation === "put") {
        if (typeof raw.data !== "string" || raw.data.length > Math.ceil(MAX_CACHE_RECORD_BYTES * 4 / 3) + 8) {
          return invalid(id, "The cache page is invalid or too large.");
        }
        if (raw.digest !== void 0 && (typeof raw.digest !== "string" || !SHA256_DIGEST.test(raw.digest))) {
          return invalid(id, "The cache page digest is invalid.");
        }
        if (raw.ciphertext !== true) return invalid(id, "The cache page must be declared ciphertext.");
      }
      return Object.freeze({
        ok: true,
        request: Object.freeze({
          kind: "cache",
          id,
          operation,
          namespace,
          ...typeof raw.key === "string" ? { key: raw.key } : {},
          ...typeof raw.data === "string" ? { data: raw.data } : {},
          ...typeof raw.digest === "string" ? { digest: raw.digest } : {},
          ...raw.ciphertext === true ? { ciphertext: true } : {}
        })
      });
    }
    if (raw.kind === "compute" && raw.operation === "sha256") {
      if (typeof raw.data !== "string" || raw.data.length > Math.ceil(MAX_VECTOR_BYTES * 4 / 3) + 8) {
        return invalid(id, "The digest input is invalid or too large.");
      }
      return Object.freeze({
        ok: true,
        request: Object.freeze({ kind: "compute", id, operation: "sha256", data: raw.data })
      });
    }
    if (raw.kind === "compute" && raw.operation === "cosine-top-k") {
      if (!Number.isSafeInteger(raw.dimensions) || Number(raw.dimensions) < 1 || Number(raw.dimensions) > MAX_VECTOR_DIMENSIONS || !Number.isSafeInteger(raw.topK) || Number(raw.topK) < 1 || Number(raw.topK) > MAX_TOP_K || !Array.isArray(raw.candidates) || raw.candidates.length === 0 || raw.candidates.length > MAX_VECTOR_CANDIDATES || typeof raw.query !== "string") return invalid(id, "The vector query shape is invalid.");
      const candidates = [];
      let encodedChars = raw.query.length;
      for (const value of raw.candidates) {
        if (!isRecord2(value) || typeof value.id !== "string" || !OPAQUE_ID.test(value.id) || typeof value.vector !== "string") {
          return invalid(id, "A vector candidate is invalid.");
        }
        encodedChars += value.vector.length;
        if (encodedChars > Math.ceil(MAX_VECTOR_BYTES * 4 / 3) + 8) {
          return invalid(id, "The vector query is too large.");
        }
        candidates.push(Object.freeze({ id: value.id, vector: value.vector }));
      }
      return Object.freeze({
        ok: true,
        request: Object.freeze({
          kind: "compute",
          id,
          operation: "cosine-top-k",
          query: raw.query,
          candidates: Object.freeze(candidates),
          dimensions: Number(raw.dimensions),
          topK: Math.min(Number(raw.topK), candidates.length || 1)
        })
      });
    }
    return invalid(id, "The companion request kind is unsupported.");
  }
  function companionReply(id, fields) {
    return Object.freeze({
      airshipCompanion: COMPANION_PROTOCOL_VERSION,
      from: "extension",
      id,
      ...fields
    });
  }
  function companionError(id, code, message) {
    return companionReply(id, {
      kind: "error",
      code: /^[a-z][a-z0-9-]{0,63}$/u.test(code) ? code : "internal-error",
      message: message.replace(/[\u0000-\u001f\u007f]+/gu, " ").slice(0, 320)
    });
  }
  function invalid(id, message) {
    return Object.freeze({ ok: false, id, code: "invalid-request", message });
  }
  async function companionCacheEnabled() {
    if (typeof indexedDB === "undefined") return false;
    const database = await openDatabase();
    try {
      const setting = await transactionRequest(database, SETTINGS_STORE, "readonly", (store) => store.get(ENABLED_SETTING));
      return setting?.value === true;
    } finally {
      database.close();
    }
  }
  function openDatabase() {
    if (typeof indexedDB === "undefined") return Promise.reject(new Error("IndexedDB is unavailable."));
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DATABASE_NAME, DATABASE_VERSION);
      request.onupgradeneeded = () => {
        const database = request.result;
        if (!database.objectStoreNames.contains(RECORD_STORE)) {
          const records = database.createObjectStore(RECORD_STORE, { keyPath: "id" });
          records.createIndex("touchedAt", "touchedAt");
          records.createIndex("namespace", "namespace");
        }
        if (!database.objectStoreNames.contains(SETTINGS_STORE)) {
          database.createObjectStore(SETTINGS_STORE, { keyPath: "key" });
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error ?? new Error("The companion database could not be opened."));
      request.onblocked = () => reject(new Error("The companion database upgrade was blocked."));
    });
  }
  function transactionRequest(database, storeName, mode, start) {
    return new Promise((resolve, reject) => {
      const transaction = database.transaction(storeName, mode);
      const request = start(transaction.objectStore(storeName));
      request.onerror = () => reject(request.error ?? new Error("The companion database request failed."));
      transaction.oncomplete = () => resolve(request.result);
      transaction.onerror = () => reject(transaction.error ?? new Error("The companion database transaction failed."));
      transaction.onabort = () => reject(transaction.error ?? new Error("The companion database transaction was aborted."));
    });
  }
  async function allRecords(database) {
    const result = await transactionRequest(database, RECORD_STORE, "readonly", (store) => store.getAll());
    return Array.isArray(result) ? result.filter(isCiphertextRecord) : [];
  }
  async function getRecord(id) {
    const database = await openDatabase();
    try {
      const result = await transactionRequest(database, RECORD_STORE, "readonly", (store) => store.get(id));
      return isCiphertextRecord(result) ? result : void 0;
    } finally {
      database.close();
    }
  }
  async function putRecord(record) {
    const database = await openDatabase();
    try {
      await transactionRequest(database, RECORD_STORE, "readwrite", (store2) => store2.put(record));
      const records = await allRecords(database);
      let bytes = records.reduce((total, entry) => total + entry.size, 0);
      let count = records.length;
      if (bytes <= MAX_CACHE_BYTES && count <= MAX_CACHE_RECORDS) return;
      const oldest = [...records].sort((left, right) => left.touchedAt - right.touchedAt);
      const transaction = database.transaction(RECORD_STORE, "readwrite");
      const store = transaction.objectStore(RECORD_STORE);
      for (const candidate of oldest) {
        if (bytes <= MAX_CACHE_BYTES && count <= MAX_CACHE_RECORDS) break;
        if (candidate.id === record.id && records.length === 1) break;
        store.delete(candidate.id);
        bytes -= candidate.size;
        count -= 1;
      }
      await transactionDone(transaction);
    } finally {
      database.close();
    }
  }
  async function removeRecord(id) {
    const database = await openDatabase();
    try {
      await transactionRequest(database, RECORD_STORE, "readwrite", (store) => store.delete(id));
    } finally {
      database.close();
    }
  }
  async function touchRecord(record) {
    const database = await openDatabase();
    try {
      await transactionRequest(database, RECORD_STORE, "readwrite", (store) => store.put(Object.freeze({ ...record, touchedAt: Date.now() })));
    } finally {
      database.close();
    }
  }
  function transactionDone(transaction) {
    return new Promise((resolve, reject) => {
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error ?? new Error("The companion database transaction failed."));
      transaction.onabort = () => reject(transaction.error ?? new Error("The companion database transaction was aborted."));
    });
  }
  function recordId(namespace, key) {
    return `${namespace}/${key}`;
  }
  function isCiphertextRecord(value) {
    if (!isRecord2(value)) return false;
    return typeof value.id === "string" && typeof value.namespace === "string" && OPAQUE_ID.test(value.namespace) && typeof value.key === "string" && OPAQUE_ID.test(value.key) && typeof value.data === "string" && typeof value.digest === "string" && SHA256_DIGEST.test(value.digest) && Number.isSafeInteger(value.size) && Number(value.size) > 0 && Number(value.size) <= MAX_CACHE_RECORD_BYTES && Number.isFinite(value.touchedAt);
  }
  function decodeBase64(value, maxBytes) {
    if (typeof value !== "string" || typeof atob !== "function") return void 0;
    try {
      const binary = atob(value);
      if (binary.length > maxBytes) return void 0;
      const bytes = new Uint8Array(binary.length);
      for (let index = 0; index < binary.length; index += 1) {
        bytes[index] = binary.charCodeAt(index) & 255;
      }
      return bytes;
    } catch {
      return void 0;
    }
  }
  function decodeVector(value, dimensions) {
    const bytes = decodeBase64(value, dimensions * 4);
    if (!bytes || bytes.byteLength !== dimensions * 4) return void 0;
    const copy = bytes.slice();
    const vector = new Float32Array(copy.buffer);
    for (const entry of vector) if (!Number.isFinite(entry)) return void 0;
    return vector;
  }
  function vectorNorm(vector) {
    let sum = 0;
    for (const value of vector) sum += value * value;
    return Math.sqrt(sum);
  }
  async function sha256(bytes) {
    const input = bytes.slice().buffer;
    const digest = new Uint8Array(await crypto.subtle.digest("SHA-256", input));
    return `sha256:${base64Url(digest)}`;
  }
  function base64Url(bytes) {
    let binary = "";
    for (let offset = 0; offset < bytes.length; offset += 32768) {
      binary += String.fromCharCode(...bytes.subarray(offset, offset + 32768));
    }
    return btoa(binary).replace(/\+/gu, "-").replace(/\//gu, "_").replace(/=+$/u, "");
  }
  async function storageEstimate() {
    try {
      const estimate = await navigator.storage?.estimate?.();
      return Object.freeze({
        ...typeof estimate?.usage === "number" ? { usage: estimate.usage } : {},
        ...typeof estimate?.quota === "number" ? { quota: estimate.quota } : {}
      });
    } catch {
      return Object.freeze({});
    }
  }
  function isRecord2(value) {
    return !!value && typeof value === "object" && !Array.isArray(value);
  }

  // extension/src/background.ts
  var callers = true ? developmentCallers() : RELEASE_CALLERS2;
  var api = resolveExtensionApi(globalThis);
  var CAPABILITY_TTL_MS = 3e4;
  var observed;
  async function observeHostAccess() {
    if (!api?.permissions) return "unknown";
    try {
      const granted = await api.permissions.contains({ origins: [...destinationMatchPatterns()] });
      return granted ? "granted" : "missing";
    } catch {
      return "unknown";
    }
  }
  async function observeCapabilities() {
    const hostAccess = await observeHostAccess();
    const userAgentOverride = hostAccess === "missing" ? "unavailable" : await installUserAgentOverride(api);
    return Object.freeze({ hostAccess, userAgentOverride });
  }
  function resolveCapabilities() {
    const now = Date.now();
    if (!observed || now - observed.at > CAPABILITY_TTL_MS) {
      observed = Object.freeze({ at: now, value: observeCapabilities() });
    }
    return observed.value;
  }
  var clock = Object.freeze({
    now: () => Date.now(),
    setTimer(delayMs, fn) {
      const timer = setTimeout(fn, delayMs);
      return () => clearTimeout(timer);
    }
  });
  var relayFetch = (url, init) => fetch(url, init);
  api?.runtime.onConnect.addListener((port) => {
    if (port.name !== BRIDGE_PORT_NAME && port.name !== COMPANION_PORT_NAME) {
      port.disconnect();
      return;
    }
    const sender = checkSender(port.sender, callers);
    if (!sender.ok) {
      port.disconnect();
      return;
    }
    if (port.name === COMPANION_PORT_NAME) {
      installCompanionPort(port);
      return;
    }
    const relay = createBridgeRelay({
      fetchImpl: relayFetch,
      clock,
      resolveCapabilities,
      send(message) {
        try {
          port.postMessage(message);
        } catch {
        }
      }
    });
    port.onMessage.addListener((message) => {
      void relay.handle(message);
    });
    port.onDisconnect.addListener(() => {
      relay.dispose();
    });
  });
})();
