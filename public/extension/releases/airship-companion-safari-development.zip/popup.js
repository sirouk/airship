// extension/src/policy.ts
var ANTHROPIC_TOKEN_USER_AGENT = "axios/1.7.9";
var ANTHROPIC_OAUTH_INFERENCE_USER_AGENT = "claude-code/1.0.0";
var BRIDGE_PROVIDERS = Object.freeze(["xai", "anthropic"]);
var BRIDGE_METHODS = Object.freeze(["GET", "POST"]);
var BRIDGE_LIMITS = Object.freeze({
  maxRequestIdLength: 128,
  maxEnvelopeKeys: 16,
  maxUrlLength: 2048,
  maxRequestBodyBytes: 256 * 1024,
  maxHeaderEntries: 16,
  maxHeaderNameLength: 64,
  maxHeaderValueLength: 8192,
  maxResponseBytes: 8 * 1024 * 1024,
  maxStreamResponseBytes: 16 * 1024 * 1024,
  maxChunkBytes: 32 * 1024,
  maxChunks: 8192,
  maxConcurrentRequests: 4,
  bufferedDeadlineMs: 6e4,
  streamDeadlineMs: 3e5,
  streamIdleDeadlineMs: 45e3
});
var BRIDGE_DESTINATIONS = Object.freeze([
  Object.freeze({
    provider: "xai",
    prefix: "https://auth.x.ai/oauth2/"
  }),
  Object.freeze({
    provider: "xai",
    prefix: "https://api.x.ai/v1/"
  }),
  // Measured: the Anthropic token host answers 429 to `Mozilla/5.0` and reaches
  // code validation for `axios/1.7.9`.
  Object.freeze({
    provider: "anthropic",
    prefix: "https://claude.ai/oauth/",
    userAgent: ANTHROPIC_TOKEN_USER_AGENT
  }),
  Object.freeze({
    provider: "anthropic",
    prefix: "https://platform.claude.com/v1/oauth/",
    userAgent: ANTHROPIC_TOKEN_USER_AGENT
  }),
  // Anthropic's OAuth inference path is served to the Claude Code fingerprint.
  // An API-key Anthropic call never comes through the bridge, so this value
  // applies only to bridged OAuth inference.
  Object.freeze({
    provider: "anthropic",
    prefix: "https://api.anthropic.com/v1/",
    userAgent: ANTHROPIC_OAUTH_INFERENCE_USER_AGENT
  })
]);
var FORWARDED_REQUEST_HEADERS = Object.freeze([
  "accept",
  "anthropic-beta",
  "anthropic-version",
  "authorization",
  "content-type",
  "user-agent",
  "x-app"
]);
var RETURNED_RESPONSE_HEADERS = Object.freeze([
  "anthropic-request-id",
  "content-type",
  "request-id",
  "retry-after",
  "x-request-id"
]);
var RELEASE_CALLERS = Object.freeze([
  Object.freeze({ origin: "https://sirouk.github.io", pathPrefix: "/airship/" })
]);

// extension/src/companion.ts
var DATABASE_NAME = "airship-companion-v1";
var DATABASE_VERSION = 1;
var RECORD_STORE = "ciphertext-pages";
var SETTINGS_STORE = "settings";
var ENABLED_SETTING = "ciphertext-cache-enabled";
var MAX_CACHE_RECORD_BYTES = 4 * 1024 * 1024;
var MAX_CACHE_BYTES = 256 * 1024 * 1024;
var MAX_CACHE_RECORDS = 4096;
var MAX_VECTOR_BYTES = 4 * 1024 * 1024;
var MAX_VECTOR_CANDIDATES = 512;
var MAX_VECTOR_DIMENSIONS = 2048;
var OPAQUE_ID = /^[A-Za-z0-9_-]{16,64}$/u;
var SHA256_DIGEST = /^sha256:[A-Za-z0-9_-]{43}$/u;
async function inspectCompanionCapabilities() {
  const computeAvailable = typeof crypto?.subtle?.digest === "function";
  let storage;
  if (typeof indexedDB === "undefined") {
    storage = Object.freeze({
      state: "unavailable",
      enabled: false,
      backend: "none",
      durability: "none",
      boundary: "ciphertext-cache-only",
      maxRecordBytes: MAX_CACHE_RECORD_BYTES,
      maxCacheBytes: MAX_CACHE_BYTES,
      maxRecords: MAX_CACHE_RECORDS,
      reason: "This extension runtime exposes no IndexedDB database."
    });
  } else {
    try {
      const [enabled, stats, estimate] = await Promise.all([
        companionCacheEnabled(),
        companionCacheStats(),
        storageEstimate()
      ]);
      storage = Object.freeze({
        state: "available",
        enabled,
        backend: "extension-indexeddb",
        durability: "extension-origin-persistent",
        boundary: "ciphertext-cache-only",
        maxRecordBytes: MAX_CACHE_RECORD_BYTES,
        maxCacheBytes: MAX_CACHE_BYTES,
        maxRecords: MAX_CACHE_RECORDS,
        usageBytes: stats.bytes,
        records: stats.records,
        ...estimate.quota !== void 0 ? { quotaBytes: estimate.quota } : {}
      });
    } catch {
      storage = Object.freeze({
        state: "unavailable",
        enabled: false,
        backend: "none",
        durability: "none",
        boundary: "ciphertext-cache-only",
        maxRecordBytes: MAX_CACHE_RECORD_BYTES,
        maxCacheBytes: MAX_CACHE_BYTES,
        maxRecords: MAX_CACHE_RECORDS,
        reason: "The extension-owned cache database could not be opened."
      });
    }
  }
  const compute = Object.freeze({
    state: computeAvailable ? "available" : "unavailable",
    execution: "extension-background",
    operations: computeAvailable ? Object.freeze(["sha256", "cosine-top-k"]) : Object.freeze([]),
    maxVectorBytes: MAX_VECTOR_BYTES,
    maxCandidates: MAX_VECTOR_CANDIDATES,
    maxDimensions: MAX_VECTOR_DIMENSIONS,
    ...computeAvailable ? {} : { reason: "This extension runtime exposes no WebCrypto digest implementation." }
  });
  return Object.freeze({ storage, compute });
}
async function setCompanionCacheEnabled(enabled) {
  const database = await openDatabase();
  try {
    await transactionRequest(database, SETTINGS_STORE, "readwrite", (store) => store.put({ key: ENABLED_SETTING, value: enabled }));
  } finally {
    database.close();
  }
}
async function clearCompanionCache() {
  const database = await openDatabase();
  try {
    await transactionRequest(database, RECORD_STORE, "readwrite", (store) => store.clear());
  } finally {
    database.close();
  }
}
async function companionCacheStats(namespace) {
  const database = await openDatabase();
  try {
    const records = (await allRecords(database)).filter((record) => namespace === void 0 || record.namespace === namespace);
    return Object.freeze({
      records: records.length,
      bytes: records.reduce((total, record) => total + record.size, 0)
    });
  } finally {
    database.close();
  }
}
async function companionCacheEnabled() {
  if (typeof indexedDB === "undefined") return false;
  const database = await openDatabase();
  try {
    const setting = await transactionRequest(database, SETTINGS_STORE, "readonly", (store) => store.get(ENABLED_SETTING));
    return setting?.value === true;
  } finally {
    database.close();
  }
}
function openDatabase() {
  if (typeof indexedDB === "undefined") return Promise.reject(new Error("IndexedDB is unavailable."));
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DATABASE_NAME, DATABASE_VERSION);
    request.onupgradeneeded = () => {
      const database = request.result;
      if (!database.objectStoreNames.contains(RECORD_STORE)) {
        const records = database.createObjectStore(RECORD_STORE, { keyPath: "id" });
        records.createIndex("touchedAt", "touchedAt");
        records.createIndex("namespace", "namespace");
      }
      if (!database.objectStoreNames.contains(SETTINGS_STORE)) {
        database.createObjectStore(SETTINGS_STORE, { keyPath: "key" });
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error("The companion database could not be opened."));
    request.onblocked = () => reject(new Error("The companion database upgrade was blocked."));
  });
}
function transactionRequest(database, storeName, mode, start) {
  return new Promise((resolve, reject) => {
    const transaction = database.transaction(storeName, mode);
    const request = start(transaction.objectStore(storeName));
    request.onerror = () => reject(request.error ?? new Error("The companion database request failed."));
    transaction.oncomplete = () => resolve(request.result);
    transaction.onerror = () => reject(transaction.error ?? new Error("The companion database transaction failed."));
    transaction.onabort = () => reject(transaction.error ?? new Error("The companion database transaction was aborted."));
  });
}
async function allRecords(database) {
  const result = await transactionRequest(database, RECORD_STORE, "readonly", (store) => store.getAll());
  return Array.isArray(result) ? result.filter(isCiphertextRecord) : [];
}
function isCiphertextRecord(value) {
  if (!isRecord(value)) return false;
  return typeof value.id === "string" && typeof value.namespace === "string" && OPAQUE_ID.test(value.namespace) && typeof value.key === "string" && OPAQUE_ID.test(value.key) && typeof value.data === "string" && typeof value.digest === "string" && SHA256_DIGEST.test(value.digest) && Number.isSafeInteger(value.size) && Number(value.size) > 0 && Number(value.size) <= MAX_CACHE_RECORD_BYTES && Number.isFinite(value.touchedAt);
}
async function storageEstimate() {
  try {
    const estimate = await navigator.storage?.estimate?.();
    return Object.freeze({
      ...typeof estimate?.usage === "number" ? { usage: estimate.usage } : {},
      ...typeof estimate?.quota === "number" ? { quota: estimate.quota } : {}
    });
  } catch {
    return Object.freeze({});
  }
}
function isRecord(value) {
  return !!value && typeof value === "object" && !Array.isArray(value);
}

// extension/src/popup.ts
var status = document.querySelector("[data-status]");
var toggle = document.querySelector("[data-cache-toggle]");
var clear = document.querySelector("[data-cache-clear]");
var usage = document.querySelector("[data-cache-usage]");
void refresh();
toggle?.addEventListener("change", () => {
  if (!toggle) return;
  toggle.disabled = true;
  void setCompanionCacheEnabled(toggle.checked).then(refresh).catch(() => showStatus("The cache setting could not be changed.", "failed"));
});
clear?.addEventListener("click", () => {
  if (!clear) return;
  clear.disabled = true;
  void clearCompanionCache().then(refresh).catch(() => showStatus("The extension cache could not be cleared.", "failed"));
});
async function refresh() {
  const capabilities = await inspectCompanionCapabilities();
  const storage = capabilities.storage;
  if (toggle) {
    toggle.disabled = storage.state !== "available";
    toggle.checked = storage.enabled;
  }
  if (clear) clear.disabled = storage.state !== "available" || (storage.records ?? 0) === 0;
  if (usage) {
    usage.textContent = storage.state === "available" ? `${storage.records ?? 0} encrypted page${storage.records === 1 ? "" : "s"} \xB7 ${formatBytes(storage.usageBytes ?? 0)}` : storage.reason ?? "Unavailable";
  }
  showStatus(
    storage.state === "available" ? storage.enabled ? "Encrypted acceleration cache is available to Airship." : "Provider relay is ready. Encrypted cache is off." : "Provider relay is ready. Extension storage is unavailable.",
    storage.state === "available" ? "ready" : "attention"
  );
}
function showStatus(message, state) {
  if (!status) return;
  status.textContent = message;
  status.dataset.state = state;
}
function formatBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KiB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MiB`;
}
